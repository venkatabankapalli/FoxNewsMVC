define({
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("flexNewsArticles", "flexNewsArticles", "flexNewsArticlesController");
        kony.mvc.registry.add("frmNews", "frmNews", "frmNewsController");
        kony.application.setCheckBoxSelectionImageAlignment(constants.CHECKBOX_SELECTION_IMAGE_ALIGNMENT_RIGHT);
        kony.application.setDefaultTextboxPadding(false);
        kony.application.setRespectImageSizeForImageWidgetAlignment(true);
        setAppBehaviors();
    },
    postAppInitCallBack: function() {},
    appmenuseq: function() {
        new kony.mvc.Navigation("frmNews").navigate();
    }
});