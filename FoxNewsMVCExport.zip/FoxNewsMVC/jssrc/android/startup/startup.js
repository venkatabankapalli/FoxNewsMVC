//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "FoxNewsMVC",
    appName: "FoxNewsMVC",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.10.12.42",
    serverPort: "80",
    secureServerPort: "443",
    isDebug: true,
    middlewareContext: "FoxNewsMVC",
    isturlbase: "http://kony145.local:8181/services",
    isMFApp: true,
    appKey: "b81e1bbf1ec5c27f831da3d5fec81c82",
    appSecret: "826e4949cc4535f1f52977ce45b18fef",
    serviceUrl: "http://kony145.local:8181/authService/100000002/appconfig",
    svcDoc: {
        "selflink": "http://kony145.local:8181/authService/100000002/appconfig",
        "identity_meta": {},
        "integsvc": {
            "FoxNews": "http://kony145.local:8181/services/FoxNews"
        },
        "appId": "13a57553-40a3-4317-901b-46d1d8d52b0f",
        "name": "FoxNewsServiceMF",
        "reportingsvc": {
            "session": "http://kony145.local:8181/services/IST",
            "custom": "http://kony145.local:8181/services/CMS"
        },
        "baseId": "dc844054-d0ef-4f3f-9b47-e9167d8efbcc",
        "login": [{
            "alias": "userstore",
            "type": "basic",
            "prov": "userstore",
            "url": "http://kony145.local:8181/authService/100000002"
        }],
        "services_meta": {
            "FoxNews": {
                "type": "integsvc",
                "version": "1.0",
                "url": "http://kony145.local:8181/services/FoxNews"
            },
            "Press": {
                "metadata_url": "http://kony145.local:8181/services/metadata/v1/Press",
                "type": "objectsvc",
                "version": "1.0",
                "url": "http://kony145.local:8181/services/data/v1/Press"
            }
        },
        "Webapp": {
            "url": "http://kony145.local:8181/VenkataEx1"
        }
    },
    svcDocRefresh: false,
    svcDocRefreshTimeSecs: -1,
    eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"],
    url: "http://kony145.local:8181/admin/FoxNewsMVC/MWServlet",
    secureurl: "http://kony145.local:8181/admin/FoxNewsMVC/MWServlet"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        isMVC: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 7300
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    applicationController = require("applicationController");
    callAppMenu();
    kony.application.setApplicationInitializationEvents({
        init: applicationController.appInit,
        showstartupform: function() {
            var startForm = new kony.mvc.Navigation("frmNews");
            startForm.navigate();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    kony.os.loadLibrary({
        "javaclassname": "com.konylabs.ffi.N_KonyLogger"
    });
    kony.os.loadLibrary({
        "javaclassname": "com.konylabs.ffi.N_binarydata"
    });
    kony.os.loadLibrary({
        "javaclassname": "com.konylabs.ffi.ND_binary_util"
    });
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "eventTypes": appConfig.eventTypes,
        "serviceUrl": appConfig.serviceUrl
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();
// If you wish to debug Application Initialization events, now is the time to
// place breakpoints.
debugger;