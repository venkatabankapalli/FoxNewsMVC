define("frmNews", function() {
    return function(controller) {
        function addWidgetsfrmNews() {
            this.setDefaultUnit(kony.flex.DP);
            var lstNewsType = new kony.ui.ListBox({
                "centerX": "50%",
                "height": "40dp",
                "id": "lstNewsType",
                "isVisible": true,
                "masterData": [
                    ["sports", "Sports"],
                    ["world", "World"],
                    ["entertainment", "Entertainment"],
                    ["none", "Select News Type"]
                ],
                "onSelection": controller.AS_ListBox_hd2f432212e14465a9c43e7851249b51,
                "selectedKey": "none",
                "selectedKeyValue": ["none", "Select News Type"],
                "skin": "sknLst1",
                "top": "5%",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "applySkinsToPopup": true,
                "viewType": constants.LISTBOX_VIEW_TYPE_LISTVIEW
            });
            var segNews = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "data": [{
                    "lblDesc": "Label",
                    "lblPubdate": "Label",
                    "lblTitle": "Label"
                }, {
                    "lblDesc": "Label",
                    "lblPubdate": "Label",
                    "lblTitle": "Label"
                }, {
                    "lblDesc": "Label",
                    "lblPubdate": "Label",
                    "lblTitle": "Label"
                }],
                "groupCells": false,
                "height": "75%",
                "id": "segNews",
                "isVisible": true,
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flexNewsArticles",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646464",
                "separatorRequired": true,
                "separatorThickness": 10,
                "showScrollbars": false,
                "top": "5%",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flexNewsArticles": "flexNewsArticles",
                    "lblDesc": "lblDesc",
                    "lblPubdate": "lblPubdate",
                    "lblTitle": "lblTitle"
                },
                "width": "95%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.add(lstNewsType, segNews);
        };
        return [{
            "addWidgets": addWidgetsfrmNews,
            "enabledForIdleTimeout": false,
            "id": "frmNews",
            "layoutType": kony.flex.FLOW_VERTICAL,
            "needAppMenu": false,
            "skin": "sknFrmBg1"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "footerOverlap": false,
            "headerOverlap": false,
            "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
            "retainScrollPosition": false,
            "titleBar": true,
            "titleBarSkin": "slTitleBar",
            "windowSoftInputMode": constants.FORM_ADJUST_PAN
        }]
    }
});