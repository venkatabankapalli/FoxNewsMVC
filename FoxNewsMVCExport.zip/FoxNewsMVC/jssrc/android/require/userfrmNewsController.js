define({
    /**
     * @function fetchNews
     *
     */
    fetchNews: function() {
        var newsType = this.view.lstNewsType.selectedKeyValue[0];
        try {
            kony.model.ApplicationContext.showLoadingScreen("Creating model for News object in Press object service ...");
            kony.model.ApplicationContext.createModel("News", "Press", {
                "access": "online"
            }, {
                "getFromServer": false
            }, createNewsModelSucessCallBack.bind(this), createNewsModelErrorCallBack);
        } catch (exception) {
            kony.model.ApplicationContext.dismissLoadingScreen();
            alert("Unable to create model for News object in Press object service ...");
        }
        /**
         * @function createNewsModelSucessCallBack
         *
         */
        function createNewsModelSucessCallBack(newsModel) {
            kony.model.ApplicationContext.dismissLoadingScreen();
            var newsDataObject = new kony.sdk.dto.DataObject("News");
            newsDataObject.setOdataUrl("newsType=" + this.view.lstNewsType.selectedKeyValue[0]);
            var options = {
                "dataObject": newsDataObject
            };
            kony.model.ApplicationContext.showLoadingScreen("Fetching news ...");
            newsModel.fetch(options, fetchDetailsFromPropertyMasterSuccesCallback.bind(this), fetchDetailsFromPropertyMasterErrorCallback);
            /**
             * @function fetchDetailsFromPropertyMasterSuccesCallback
             *
             */
            function fetchDetailsFromPropertyMasterSuccesCallback(successResponse) {
                kony.model.ApplicationContext.dismissLoadingScreen();
                kony.print("In fetchDetailsFromPropertyMasterSuccesCallback: Response: " + JSON.stringify(successResponse));
                //alert (JSON.stringify(successResponse));
                this.setResponse(successResponse);
            }
            /**
             * @function fetchDetailsFromPropertyMasterErrorCallback
             *
             */
            function fetchDetailsFromPropertyMasterErrorCallback(errorResponse) {
                kony.model.ApplicationContext.dismissLoadingScreen();
                alert("In fetchDetailsFromPropertyMasterErrorCallback: Error: " + JSON.stringify(errorResponse));
            }
        }
        /**
         * @function createNewsModelErrorCallBack
         *
         */
        function createNewsModelErrorCallBack(error) {
            kony.model.ApplicationContext.dismissLoadingScreen();
            alert("In createNewsModelErrorCallBack: Error: " + JSON.stringify(error));
        }
    },
    /**
     * @function setResponse
     *
     */
    setResponse: function(successResponse) {
        this.view.segNews.widgetDataMap = {
            "lblTitle": "title",
            "lblDesc": "desc",
            "lblPubdate": "pubdate"
        };
        this.view.segNews.setData(successResponse[0].articles);
    }
});