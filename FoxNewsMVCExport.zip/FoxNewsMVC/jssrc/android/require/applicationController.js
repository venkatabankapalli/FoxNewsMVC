define({
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("flexNewsArticles", "flexNewsArticles", "flexNewsArticlesController");
        kony.mvc.registry.add("frmNews", "frmNews", "frmNewsController");
        setAppBehaviors();
    },
    postAppInitCallBack: function() {},
    appmenuseq: function() {
        new kony.mvc.Navigation("frmNews").navigate();
    }
});