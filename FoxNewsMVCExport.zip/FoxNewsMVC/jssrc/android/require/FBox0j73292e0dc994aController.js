define(function(){
	var controller = require("userFBox0j73292e0dc994aController");
	var controllerActions = ["FBox0j73292e0dc994aControllerActions"];

	for(var i = 0; i < controllerActions.length; i++){
		var actions = require(controllerActions[i]);
		for(var key in actions){
			controller[key] = actions[key];
		}
	}

	return controller;
})