define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_ListBox_hd2f432212e14465a9c43e7851249b51: function AS_ListBox_hd2f432212e14465a9c43e7851249b51(eventobject) {
        var self = this;
        this.fetchNews();
    }
});